// Merit Hall: máy chủ nhỏ chạy trên Netlify Functions, lưu dữ liệu bằng Netlify Blobs.
// Biến môi trường cần đặt trên Netlify: TEACHER_PASSWORD (bắt buộc), TEACHER_NAME (tùy chọn), TOKEN_SECRET (tùy chọn).
import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";

export const config = { path: "/api/*" };

const LVS = ["g12", "pet", "ielts"];
const SKS = ["listen", "speak", "read", "write"];
const PHUOC = ["Phước học đâu nhớ đó", "Phước làm bài đúng ngay lần đầu", "Phước thi đâu đỗ đó", "Phước điểm cao như ý", "Phước gặp đề trúng tủ", "Phước nghe hiểu từ đầu đến cuối", "Phước không quên từ vựng khi vào phòng thi", "Phước viết bài trôi chảy", "Phước tâm an, bút sáng"];

// globalThis.__MH_STORE chỉ dùng khi chạy thử trên máy; trên Netlify luôn dùng Blobs thật.
const db = () => globalThis.__MH_STORE || getStore({ name: "merit-hall", consistency: "strong" });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });
const fail = (msg, status = 400) => json({ error: msg }, status);
const uid = () => crypto.randomBytes(5).toString("hex");
const norm = (s) => String(s).toLowerCase().replace(/[‘’`]/g, "'").replace(/[.!?,;:]+$/g, "").replace(/\s+/g, " ").trim();

/* ---------- Lưu trữ ---------- */
async function get(key) { return (await db().get(key, { type: "json" })) || null; }
async function put(key, val) { await db().setJSON(key, val); }
async function del(key) { await db().delete(key); }
async function list(prefix) {
  const { blobs } = await db().list({ prefix });
  const rows = await Promise.all(blobs.map((b) => get(b.key)));
  return rows.filter(Boolean);
}

/* ---------- Mật khẩu và token ---------- */
function hashPw(pw) {
  const salt = crypto.randomBytes(16);
  return salt.toString("hex") + ":" + crypto.scryptSync(String(pw), salt, 32).toString("hex");
}
function checkPw(pw, stored) {
  try {
    const [s, h] = String(stored).split(":");
    const a = crypto.scryptSync(String(pw), Buffer.from(s, "hex"), 32), b = Buffer.from(h, "hex");
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch { return false; }
}
function secret() { return process.env.TOKEN_SECRET || crypto.createHash("sha256").update("merit-hall:" + (process.env.TEACHER_PASSWORD || "")).digest("hex"); }
function sign(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  return body + "." + crypto.createHmac("sha256", secret()).update(body).digest("base64url");
}
function verify(token) {
  try {
    const [body, mac] = String(token).split(".");
    const good = crypto.createHmac("sha256", secret()).update(body).digest("base64url");
    if (mac.length !== good.length || !crypto.timingSafeEqual(Buffer.from(mac), Buffer.from(good))) return null;
    const p = JSON.parse(Buffer.from(body, "base64url").toString());
    return p.exp > Date.now() ? p : null;
  } catch { return null; }
}
function same(a, b) {
  const x = crypto.createHash("sha256").update(String(a)).digest(), y = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
}
const slug = (name) => String(name).normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]/g, "") || "hs";
const randPass = () => String(crypto.randomInt(0, 1000000)).padStart(6, "0");

/* ---------- Kiểm tra dữ liệu bài tập ---------- */
function cleanSet(b, id) {
  const str = (v, n) => String(v == null ? "" : v).slice(0, n);
  if (!b || !str(b.title, 120).trim()) throw "Hãy nhập tên bài.";
  if (!LVS.includes(b.lv)) throw "Trình độ không hợp lệ.";
  if (!SKS.includes(b.skill)) throw "Kỹ năng không hợp lệ.";
  if (!Array.isArray(b.qs) || !b.qs.length || b.qs.length > 60) throw "Bài cần từ 1 đến 60 câu.";
  const qs = b.qs.map((q, i) => {
    const o = { q: str(q.q, 1500).trim(), why: str(q.why, 800).trim() };
    if (!o.q) throw "Câu " + (i + 1) + ": hãy nhập câu hỏi.";
    if (b.skill === "listen") { o.audio = str(q.audio, 3000).trim(); if (!o.audio) throw "Câu " + (i + 1) + ": hãy nhập nội dung để đọc to."; }
    if (b.skill === "read") { o.passage = str(q.passage, 6000).trim(); if (!o.passage) throw "Câu " + (i + 1) + ": hãy nhập đoạn văn."; }
    if (b.skill === "write") {
      o.answers = (Array.isArray(q.answers) ? q.answers : []).map((x) => str(x, 200).trim()).filter(Boolean);
      if (!o.answers.length) throw "Câu " + (i + 1) + ": hãy nhập ít nhất một đáp án chấp nhận.";
    } else {
      o.o = (Array.isArray(q.o) ? q.o : []).map((x) => str(x, 300).trim());
      if (o.o.length < 2 || o.o.length > 4 || o.o.some((x) => !x)) throw "Câu " + (i + 1) + ": cần từ 2 đến 4 đáp án, không để trống.";
      if (!Number.isInteger(q.a) || q.a < 0 || q.a >= o.o.length) throw "Câu " + (i + 1) + ": hãy chọn đáp án đúng.";
      o.a = q.a;
    }
    return o;
  });
  return { id, title: str(b.title, 120).trim(), lv: b.lv, skill: b.skill, due: /^\d{4}-\d{2}-\d{2}$/.test(b.due || "") ? b.due : "", qs };
}
const isText = (q) => Array.isArray(q.answers);
const publicStudent = (s) => ({ id: s.id, name: s.name, user: s.user, lv: s.lv });
const subKey = (sid, e) => "subs/" + sid + "~" + e;

async function sticksOf(sid) {
  const subs = await list("subs/" + sid + "~");
  const prog = (await get("prog/" + sid)) || { lit: 0, blessTotal: 0, last: [] };
  return { sticks: Math.max(0, subs.reduce((a, x) => a + (x.c || 0), 0) - 3 * prog.lit), prog };
}

/* ---------- Xử lý yêu cầu ---------- */
export default async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const m = req.method;
  let body = {};
  if (m === "POST" || m === "PUT") { try { body = await req.json(); } catch { body = {}; } }

  try {
    if (parts[0] === "login" && m === "POST") {
      await sleep(250);
      const day = 1000 * 60 * 60 * 24;
      if (body.role === "teacher") {
        if (!process.env.TEACHER_PASSWORD) return fail("Chưa cài biến môi trường TEACHER_PASSWORD trên Netlify.", 503);
        if (!same(body.pass || "", process.env.TEACHER_PASSWORD)) { await sleep(600); return fail("Sai mật khẩu giáo viên.", 401); }
        return json({ token: sign({ r: "t", exp: Date.now() + 14 * day }), role: "teacher", name: process.env.TEACHER_NAME || "Giáo viên" });
      }
      const user = String(body.user || "").trim().toLowerCase();
      const st = (await list("students/")).find((s) => s.user === user);
      if (!st || !checkPw(body.pass || "", st.pw)) { await sleep(600); return fail("Sai tên đăng nhập hoặc mật khẩu.", 401); }
      return json({ token: sign({ r: "s", sid: st.id, exp: Date.now() + 30 * day }), role: "student", name: st.name, lv: st.lv });
    }

    const auth = verify((req.headers.get("authorization") || "").replace(/^Bearer /, ""));
    if (!auth) return fail("Phiên đăng nhập đã hết hạn, hãy đăng nhập lại.", 401);

    /* ----- Giáo viên ----- */
    if (parts[0] === "t") {
      if (auth.r !== "t") return fail("Không có quyền.", 403);
      const [, a, b, c] = parts;
      if (a === "overview" && m === "GET") {
        const [students, sets, subs] = await Promise.all([list("students/"), list("sets/"), list("subs/")]);
        return json({ students: students.map(publicStudent), sets, subs: subs.filter((x) => x.at > 0) });
      }
      if (a === "students" && b === "bulk" && m === "POST") {
        const names = (Array.isArray(body.names) ? body.names : []).map((x) => String(x).trim().slice(0, 80)).filter(Boolean).slice(0, 80);
        if (!names.length) return fail("Hãy nhập ít nhất một tên.");
        if (!LVS.includes(body.lv)) return fail("Trình độ không hợp lệ.");
        const used = new Set((await list("students/")).map((s) => s.user)), created = [];
        for (const name of names) {
          let u = slug(name), n = 2; const base = u;
          while (used.has(u)) u = base + n++;
          used.add(u);
          const pass = randPass(), id = uid();
          await put("students/" + id, { id, name, user: u, pw: hashPw(pass), lv: body.lv });
          created.push({ name, user: u, pass });
        }
        return json({ created });
      }
      if (a === "students" && !b && m === "POST") {
        const name = String(body.name || "").trim().slice(0, 80), user = slug(body.user || ""), pass = String(body.pass || "");
        if (!name || !body.user || pass.length < 4) return fail("Cần nhập họ tên, tên đăng nhập và mật khẩu (ít nhất 4 ký tự).");
        if (!LVS.includes(body.lv)) return fail("Trình độ không hợp lệ.");
        if ((await list("students/")).some((s) => s.user === user)) return fail("Tên đăng nhập này đã có người dùng.");
        const id = uid();
        await put("students/" + id, { id, name, user, pw: hashPw(pass), lv: body.lv });
        return json({ created: [{ name, user, pass }] });
      }
      if (a === "students" && b && m === "PUT") {
        const st = await get("students/" + b);
        if (!st) return fail("Không tìm thấy học sinh.", 404);
        if (body.name && String(body.name).trim()) st.name = String(body.name).trim().slice(0, 80);
        if (LVS.includes(body.lv)) st.lv = body.lv;
        let pass = null;
        if (body.reset) { pass = randPass(); st.pw = hashPw(pass); }
        await put("students/" + b, st);
        return json({ ok: true, pass, name: st.name, user: st.user });
      }
      if (a === "students" && b && m === "DELETE") {
        await del("students/" + b); await del("prog/" + b);
        for (const x of await list("subs/" + b + "~")) await del(subKey(b, x.e));
        return json({ ok: true });
      }
      if (a === "sets" && !b && m === "POST") {
        let set;
        try { set = cleanSet(body, /^[a-f0-9]{10}$/.test(body.id || "") ? body.id : uid()); } catch (e) { return fail(typeof e === "string" ? e : "Dữ liệu không hợp lệ."); }
        await put("sets/" + set.id, set);
        return json({ ok: true, id: set.id });
      }
      if (a === "sets" && b && m === "DELETE") {
        await del("sets/" + b);
        for (const x of await list("subs/")) if (x.e === b) await del(subKey(x.sid, b));
        return json({ ok: true });
      }
      if (a === "subs" && b && c && m === "DELETE") { await del(subKey(b, c)); return json({ ok: true }); }
      return fail("Không tìm thấy.", 404);
    }

    /* ----- Học sinh ----- */
    if (parts[0] === "s") {
      if (auth.r !== "s") return fail("Không có quyền.", 403);
      const st = await get("students/" + auth.sid);
      if (!st) return fail("Tài khoản không còn tồn tại.", 401);
      const [, a, b] = parts;
      if (a === "home" && m === "GET") {
        const [sets, subs, sp] = await Promise.all([list("sets/"), list("subs/" + st.id + "~"), sticksOf(st.id)]);
        const mine = sets.filter((s) => s.lv === st.lv).map((s) => {
          const sub = subs.find((x) => x.e === s.id);
          return { id: s.id, title: s.title, lv: s.lv, skill: s.skill, due: s.due, n: s.qs.length, answered: sub ? sub.a.length : 0, c: sub ? sub.c : 0 };
        });
        return json({ student: { name: st.name, lv: st.lv }, sets: mine, sticks: sp.sticks, blessTotal: sp.prog.blessTotal, last: sp.prog.last });
      }
      if (a === "set" && b && m === "GET") {
        const set = await get("sets/" + b);
        if (!set || set.lv !== st.lv) return fail("Không tìm thấy bài tập.", 404);
        const sub = await get(subKey(st.id, b));
        const qs = set.qs.map((q) => ({ q: q.q, passage: q.passage || "", audio: q.audio || "", o: q.o || null, text: isText(q) }));
        return json({ id: set.id, title: set.title, lv: set.lv, skill: set.skill, due: set.due, qs, a: sub ? sub.a : [], c: sub ? sub.c : 0 });
      }
      if (a === "answer" && m === "POST") {
        const set = await get("sets/" + body.setId);
        if (!set || set.lv !== st.lv) return fail("Không tìm thấy bài tập.", 404);
        const sub = (await get(subKey(st.id, set.id))) || { sid: st.id, e: set.id, a: [], c: 0, t: set.qs.length, at: 0 };
        if (body.qi !== sub.a.length) return json({ error: "Câu này đã được trả lời.", a: sub.a, c: sub.c }, 409);
        const q = set.qs[body.qi];
        if (!q) return fail("Không có câu này.");
        let choice, ok;
        if (isText(q)) { choice = String(body.choice == null ? "" : body.choice).slice(0, 200); ok = q.answers.map(norm).includes(norm(choice)); }
        else { choice = Number(body.choice); if (!Number.isInteger(choice) || choice < 0 || choice >= q.o.length) return fail("Đáp án không hợp lệ."); ok = choice === q.a; }
        sub.a.push(choice); if (ok) sub.c += 1; sub.t = set.qs.length;
        if (sub.a.length >= set.qs.length) sub.at = Date.now();
        await put(subKey(st.id, set.id), sub);
        return json({ ok, correctIndex: isText(q) ? null : q.a, answer: isText(q) ? q.answers[0] : null, why: q.why || "", done: sub.at > 0, c: sub.c });
      }
      if (a === "light" && m === "POST") {
        const sp = await sticksOf(st.id);
        if (sp.sticks < 3) return fail("Chưa đủ 3 cây nhang.");
        const pool = PHUOC.slice(), pick = [];
        while (pick.length < 3) pick.push(pool.splice(crypto.randomInt(0, pool.length), 1)[0]);
        sp.prog.lit += 1; sp.prog.blessTotal += 3; sp.prog.last = pick;
        await put("prog/" + st.id, sp.prog);
        return json({ sticks: sp.sticks - 3, blessTotal: sp.prog.blessTotal, last: pick });
      }
      return fail("Không tìm thấy.", 404);
    }
    return fail("Không tìm thấy.", 404);
  } catch (e) {
    console.error(e);
    return fail("Máy chủ gặp lỗi, thử lại sau.", 500);
  }
};
