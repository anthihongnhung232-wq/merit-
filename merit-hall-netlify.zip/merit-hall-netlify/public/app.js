(function () {
  var LV = { g12: "Lớp 12", pet: "PET", ielts: "IELTS" };
  var LVO = ["g12", "pet", "ielts"];
  var SK = { listen: "Nghe", speak: "Nói", read: "Đọc", write: "Viết" };
  var SKO = ["listen", "speak", "read", "write"];
  var LET = ["A", "B", "C", "D"];
  var SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">';
  var ICON = {
    listen: SVG + '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg>',
    speak: SVG + '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg>',
    read: SVG + '<path d="M4 5a2 2 0 0 1 2-2h13v15H6a2 2 0 0 0-2 2z"/><path d="M4 20a2 2 0 0 0 2 2h13v-4"/></svg>',
    write: SVG + '<path d="M4 20l1-4L16 5l3 3L8 19z"/><path d="M14 7l3 3"/></svg>',
    stick: '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><line x1="12" y1="7" x2="12" y2="22" stroke="currentColor" stroke-width="3" stroke-linecap="round"/><circle cx="12" cy="4.5" r="3" fill="#E8541E"/></svg>'
  };
  var LOGO = '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 26 Q8 42 24 43 Q40 42 40 26 Z" fill="#8A5A2B"/><ellipse cx="24" cy="26" rx="16" ry="4" fill="#6C4CF5"/><line x1="18" y1="26" x2="16" y2="9" stroke="#C77D12" stroke-width="2.5" stroke-linecap="round"/><line x1="24" y1="26" x2="24" y2="6" stroke="#C77D12" stroke-width="2.5" stroke-linecap="round"/><line x1="30" y1="26" x2="32" y2="9" stroke="#C77D12" stroke-width="2.5" stroke-linecap="round"/><circle cx="16" cy="8" r="2" fill="#E8541E"/><circle cx="24" cy="5" r="2" fill="#E8541E"/><circle cx="32" cy="8" r="2" fill="#E8541E"/></svg>';
  var STUAV = '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 28 Q8 42 24 43 Q40 42 40 28 Z" fill="#8A5A2B"/><ellipse cx="24" cy="28" rx="16" ry="4" fill="#D3CFE6"/><line x1="20" y1="28" x2="19" y2="14" stroke="#C77D12" stroke-width="2.5" stroke-linecap="round"/><line x1="28" y1="28" x2="29" y2="14" stroke="#C77D12" stroke-width="2.5" stroke-linecap="round"/></svg>';

  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  function lsGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function lsDel(k) { try { localStorage.removeItem(k); } catch (e) {} }
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch (e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch (e) {} }
  function ssDel(k) { try { sessionStorage.removeItem(k); } catch (e) {} }
  function pad(n) { return String(n).padStart(2, "0"); }
  function todayStr(add) { var d = new Date(); d.setDate(d.getDate() + (add || 0)); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
  function fmtDue(s) { var p = String(s || "").split("-"); return p.length === 3 ? p[2] + "/" + p[1] + "/" + p[0] : ""; }
  function fmtAt(ms) { var d = new Date(ms); return pad(d.getHours()) + ":" + pad(d.getMinutes()) + " " + pad(d.getDate()) + "-" + pad(d.getMonth() + 1); }
  function norm(s) { return String(s).toLowerCase().replace(/[‘’`]/g, "'").replace(/[.!?,;:]+$/g, "").replace(/\s+/g, " ").trim(); }
  function byId(list, id) { for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i]; return null; }
  function isText(q) { return Array.isArray(q.answers); }

  var token = lsGet("mh-token"), role = lsGet("mh-role"), who = lsGet("mh-name") || "";
  var T = null, H = null, Q = null;
  var view = { tt: "sets", lvF: "", skF: "", confirm: "", err: "", msg: "", editing: null, draft: null, editStu: null, openSub: null, burning: false, loginAs: "student", busy: false, fresh: [] };
  try { view.fresh = JSON.parse(ssGet("mh-fresh") || "[]"); } catch (e) {}
  var burnTimer = null, poll = null;

  /* ---------- Gọi máy chủ ---------- */
  async function api(method, path, body) {
    var r = await fetch("/api/" + path, { method: method, headers: Object.assign({ "content-type": "application/json" }, token ? { authorization: "Bearer " + token } : {}), body: body ? JSON.stringify(body) : undefined });
    var d = {};
    try { d = await r.json(); } catch (e) {}
    if (r.status === 401 && token && path !== "login") { var m = d.error; logout(); view.err = m || "Phiên đăng nhập đã hết hạn."; render(); throw { handled: true }; }
    if (!r.ok) { var e = new Error(d.error || "Có lỗi xảy ra, thử lại sau."); e.status = r.status; e.data = d; throw e; }
    return d;
  }
  function logout() { token = null; role = null; who = ""; T = null; H = null; Q = null; lsDel("mh-token"); lsDel("mh-role"); lsDel("mh-name"); view.editing = null; view.draft = null; view.burning = false; clearInterval(poll); }
  async function loadT() { T = await api("GET", "t/overview"); }
  async function loadH() { H = await api("GET", "s/home"); }
  // Chạy một thao tác của giáo viên rồi tải lại dữ liệu.
  async function tact(fn) {
    view.err = ""; view.busy = true;
    try { await fn(); } catch (e) { if (e && e.handled) return; view.err = e.message || "Có lỗi xảy ra."; }
    try { await loadT(); } catch (e) { if (e && e.handled) return; }
    view.busy = false; render();
  }

  /* ---------- Khung chung ---------- */
  function header(right) {
    return '<header class="top"><div class="top-in"><div class="brand">' + LOGO + "<span>Merit Hall</span></div>" + (right ? '<div class="who">' + right + "</div>" : "") + "</div></header>";
  }
  function pills(s, n) {
    return '<span class="pill solid">' + LV[s.lv] + '</span><span class="pill solid">' + ICON[s.skill] + SK[s.skill] + '</span><span class="pill">' + n + ' câu</span><span class="pill gold">' + ICON.stick + n + "</span>";
  }
  function lvOptions(sel) { return LVO.map(function (l) { return '<option value="' + l + '"' + (sel === l ? " selected" : "") + ">" + LV[l] + "</option>"; }).join(""); }

  /* ---------- Đăng nhập ---------- */
  function loginHTML() {
    var t = view.loginAs === "teacher";
    return header("") + '<main class="page"><form class="card login" data-form="login" autocomplete="off"><h2>' + (t ? "Đăng nhập giáo viên" : "Đăng nhập") + "</h2>" +
      (t ? "" : '<div class="field"><label for="l-user">Tên đăng nhập</label><input id="l-user" type="text" autocapitalize="none" autocomplete="username" value="' + esc(view.lu || "") + '"></div>') +
      '<div class="field"><label for="l-pin">Mật khẩu</label><input id="l-pin" type="password" autocomplete="current-password"></div>' +
      (view.err ? '<p class="err" role="alert">' + esc(view.err) + "</p>" : "") +
      '<button class="btn" type="submit"' + (view.busy ? " disabled" : "") + ">" + (view.busy ? "Đang vào..." : t ? "Vào khu giáo viên" : "Vào học") + "</button></form>" +
      '<p style="text-align:center"><button class="txtbtn" type="button" data-act="login-as" data-as="' + (t ? "student" : "teacher") + '">' + (t ? "Tôi là học sinh" : "Dành cho giáo viên") + "</button></p></main>";
  }
  async function doLogin() {
    var t = view.loginAs === "teacher";
    if (!t) view.lu = $("l-user").value;
    var pw = $("l-pin").value;
    view.busy = true; view.err = ""; render();
    try {
      var d = await api("POST", "login", { role: t ? "teacher" : "student", user: t ? "" : view.lu, pass: pw });
      token = d.token; role = d.role; who = d.name; lsSet("mh-token", token); lsSet("mh-role", role); lsSet("mh-name", who);
      view.tt = "sets"; view.busy = false;
      render();
      await boot();
    } catch (e) { view.busy = false; if (!e.handled) { view.err = e.message; render(); } }
  }
  async function boot() {
    try { if (role === "teacher") await loadT(); else await loadH(); } catch (e) { if (!e.handled) { view.err = e.message; } }
    clearInterval(poll);
    if (role === "teacher") poll = setInterval(function () { if (!document.hidden && view.tt === "subs" && !view.busy) loadT().then(render).catch(function () {}); }, 15000);
    render();
  }

  /* ---------- Lư hương ---------- */
  var SLOTS = [{ x: 92, tx: 86 }, { x: 120, tx: 120 }, { x: 148, tx: 154 }];
  function altarSVG() {
    var shown = view.burning ? 3 : Math.min(3, H.sticks), s = "";
    for (var i = 0; i < 3; i++) {
      var sl = SLOTS[i];
      s += '<path class="smoke s' + i + '" d="M' + sl.tx + " 70 C" + (sl.tx - 12) + " 52 " + (sl.tx + 12) + " 40 " + sl.tx + " 22 C" + (sl.tx - 10) + " 6 " + (sl.tx + 10) + " -6 " + sl.tx + ' -16"/>';
    }
    for (var j = 0; j < 3; j++) {
      var o = SLOTS[j];
      if (j < shown) {
        s += '<line x1="' + o.x + '" y1="158" x2="' + o.tx + '" y2="76" stroke="var(--stick)" stroke-width="3" stroke-linecap="round"/>';
        s += '<circle class="tip' + (view.burning ? " lit" : "") + '" cx="' + o.tx + '" cy="74" r="3.6" fill="var(--bowl)"/>';
      } else s += '<circle cx="' + o.x + '" cy="159" r="3" fill="var(--bowl)" opacity=".6"/>';
    }
    var bowl = '<path d="M36 160 Q36 232 120 238 Q204 232 204 160 Z" fill="var(--bowl)"/><ellipse cx="120" cy="160" rx="84" ry="15" fill="var(--bowl)"/><ellipse cx="120" cy="160" rx="72" ry="10" fill="var(--ash)"/><path d="M54 196 Q120 214 186 196" fill="none" stroke="var(--surface)" stroke-width="2" opacity=".45"/><rect x="78" y="236" width="14" height="10" rx="2" fill="var(--bowl)"/><rect x="148" y="236" width="14" height="10" rx="2" fill="var(--bowl)"/>';
    return '<svg id="altar" class="' + (view.burning ? "burning" : "") + '" viewBox="0 -20 240 280" role="img" aria-label="Lư hương cắm nhang">' + bowl + s + "</svg>";
  }
  function altarCard() {
    var need = 3 - H.sticks;
    var h = '<section class="card altarcard">' + altarSVG() + '<div class="altarinfo"><div class="stats"><div class="stat"><div class="n">' + H.sticks + '</div><div class="l">cây nhang đang có</div></div><div class="stat"><div class="n">' + H.blessTotal + '</div><div class="l">phước đã nhận</div></div></div>';
    h += '<div class="meter" aria-hidden="true">' + [0, 1, 2].map(function (k) { return "<i" + (k < Math.min(3, H.sticks) ? ' class="on"' : "") + "></i>"; }).join("") + "</div>";
    h += '<div class="row"><button class="btn" type="button" data-act="light"' + (H.sticks < 3 || view.burning ? " disabled" : "") + ">Thắp nhang xin 3 phước</button></div>";
    h += '<p class="hint">' + (view.burning ? "Nhang đang cháy..." : need > 0 ? "Còn thiếu " + need + " cây nhang." : "Đủ nhang rồi, bạn thắp lên nhé.") + "</p>";
    if (H.last && H.last.length) h += '<div class="blessing"><h3>Thầy ban cho bạn</h3><ol>' + H.last.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ol></div>";
    return h + "</div></section>";
  }
  async function lightIncense() {
    if (H.sticks < 3 || view.burning) return;
    try {
      var d = await api("POST", "s/light");
      H.sticks = d.sticks; H.blessTotal = d.blessTotal; H.last = d.last;
      view.burning = true; render();
      clearTimeout(burnTimer);
      burnTimer = setTimeout(function () { view.burning = false; render(); }, 7000);
    } catch (e) { if (!e.handled) { view.err = e.message; render(); } }
  }

  /* ---------- Học sinh ---------- */
  function studentHome() {
    var sets = H.sets.filter(function (s) { return !view.skF || s.skill === view.skF; });
    var h = altarCard();
    h += '<div class="bar"><h2>Bài tập của bạn</h2><select id="sk-f" aria-label="Lọc theo kỹ năng"><option value="">Mọi kỹ năng</option>' + SKO.map(function (k) { return '<option value="' + k + '"' + (view.skF === k ? " selected" : "") + ">" + SK[k] + "</option>"; }).join("") + "</select></div>";
    if (view.err) h += '<p class="err" role="alert">' + esc(view.err) + "</p>";
    if (!sets.length) return h + '<div class="card"><div class="empty"><h3>Chưa có bài tập</h3><p>Giáo viên chưa giao bài nào cho bạn. Quay lại sau nhé.</p></div></div>';
    sets.forEach(function (s) {
      var done = s.answered >= s.n, late = s.due && s.due < todayStr() && !done;
      h += '<div class="card set"><div class="meta"><b>' + esc(s.title) + '</b><div class="chips">' + pills(s, s.n) +
        (s.due ? '<span class="dim">Hạn ' + fmtDue(s.due) + "</span>" : "") + (late ? '<span class="pill bad">Quá hạn</span>' : "") +
        (done ? '<span class="pill good">' + s.c + "/" + s.n + "</span>" : "") + '</div></div>' +
        '<button class="btn' + (done ? " alt" : "") + '" type="button" data-act="open" data-id="' + s.id + '">' + (done ? "Xem kết quả" : s.answered > 0 ? "Làm tiếp" : "Làm bài") + "</button></div>";
    });
    return h;
  }
  async function openSet(id) {
    try { Q = await api("GET", "s/set/" + id); Q.qi = Q.a.length; Q.fb = null; render(); }
    catch (e) { if (!e.handled) { view.err = e.message; render(); } }
  }
  function quizView() {
    var n = Q.qs.length;
    var h = '<div class="bar"><button class="btn alt" type="button" data-act="back">Quay lại</button><div class="chips">' + pills(Q, n) + "</div></div>";
    if (Q.qi >= n) {
      return h + '<section class="card"><h2>' + esc(Q.title) + '</h2><div class="chips"><span class="pill good">Đúng ' + Q.c + "/" + n + '</span><span class="pill gold">' + ICON.stick + "+" + Q.c + " nhang</span></div>" +
        '<p>Bạn đã làm xong bài này. Bài nộp đã được gửi cho giáo viên.</p><div class="row"><button class="btn" type="button" data-act="back">Về danh sách bài</button></div></section>';
    }
    var q = Q.qs[Q.qi], answered = !!Q.fb, choice = Q.a[Q.qi];
    h += '<section class="card"><div class="prog" role="progressbar" aria-valuemin="0" aria-valuemax="' + n + '" aria-valuenow="' + Q.qi + '"><i style="width:' + Math.round(Q.qi / n * 100) + '%"></i></div><span class="qtag">Câu ' + (Q.qi + 1) + "/" + n + "</span>";
    if (q.passage) h += '<blockquote class="passage">' + esc(q.passage) + "</blockquote>";
    if (q.audio) h += '<div class="row"><button class="btn alt" type="button" data-act="play">' + ICON.listen + ' Nghe</button><span class="hint">Bạn có thể nghe lại nhiều lần.</span></div>';
    h += '<p class="qtext">' + esc(q.q) + "</p>";
    if (q.text) {
      h += '<form class="typed" data-form="type"><input id="typed" type="text" autocomplete="off" autocapitalize="none" aria-label="Câu trả lời của bạn"' + (answered ? ' value="' + esc(choice) + '" disabled' : "") + ">" + (answered ? "" : '<button class="btn" type="submit"' + (view.busy ? " disabled" : "") + ">Kiểm tra</button>") + "</form>";
    } else {
      h += '<div class="opts">' + q.o.map(function (o, i) {
        var c = "opt";
        if (answered && i === Q.fb.ci) c += " right"; else if (answered && i === choice) c += " wrong";
        return '<button class="' + c + '" type="button" data-opt="' + i + '"' + (answered || view.busy ? " disabled" : "") + "><b>" + LET[i] + "</b><span>" + esc(o) + "</span></button>";
      }).join("") + "</div>";
    }
    if (view.err) h += '<p class="err" role="alert">' + esc(view.err) + "</p>";
    if (answered) {
      h += '<div class="fb ' + (Q.fb.ok ? "ok" : "no") + '"><strong>' + (Q.fb.ok ? "Đúng rồi! +1 cây nhang" : "Chưa đúng") + "</strong>" +
        (!Q.fb.ok && q.text ? "Đáp án: " + esc(Q.fb.ans) + ". " : "") + (Q.fb.why ? esc(Q.fb.why) : "") + "</div>" +
        '<div class="row"><button class="btn" type="button" data-act="next">' + (Q.qi + 1 >= n ? "Xem kết quả" : "Câu tiếp") + "</button></div>";
    }
    return h + "</section>";
  }
  async function answerQ(choice) {
    if (Q.fb || view.busy) return;
    view.busy = true; view.err = ""; render();
    try {
      var d = await api("POST", "s/answer", { setId: Q.id, qi: Q.qi, choice: choice });
      Q.a.push(choice); Q.c = d.c; Q.fb = { ok: d.ok, ci: d.correctIndex, ans: d.answer, why: d.why };
    } catch (e) {
      if (e.handled) return;
      if (e.status === 409 && e.data) { Q.a = e.data.a; Q.c = e.data.c; Q.qi = Q.a.length; Q.fb = null; }
      else view.err = e.message;
    }
    view.busy = false; render();
    var f = document.querySelector(".fb"); if (f && f.scrollIntoView) f.scrollIntoView({ block: "nearest" });
  }
  function speak(text) {
    if (!text) return;
    try { speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(text); u.lang = "en-US"; u.rate = .9; speechSynthesis.speak(u); } catch (e) {}
  }

  /* ---------- Giáo viên ---------- */
  function confirmBtn(act, id, label, extra) {
    var key = act + ":" + id + (extra || "");
    var attrs = ' data-act="' + act + '" data-id="' + id + '"' + (extra ? ' data-x="' + extra + '"' : "");
    if (view.confirm === key) return '<span class="row"><span class="dim">Chắc chắn?</span><button class="txtbtn red" type="button"' + attrs + ' data-yes="1">' + label + '</button><button class="txtbtn" type="button" data-act="c-no">Không</button></span>';
    return '<button class="txtbtn' + (label === "Xóa" ? " red" : "") + '" type="button"' + attrs + ">" + label + "</button>";
  }
  function teacherHTML() {
    var out = header(esc(who) + '<button class="txtbtn" type="button" data-act="logout">Đăng xuất</button>') + '<main class="page">';
    var tabs = [["sets", "Bài tập"], ["students", "Học sinh"], ["subs", "Bài đã nộp"], ["settings", "Cài đặt"]];
    out += '<div class="tabs" role="tablist">' + tabs.map(function (t) { return '<button class="tab" role="tab" type="button" data-act="t-tab" data-tt="' + t[0] + '" aria-selected="' + (view.tt === t[0]) + '">' + t[1] + "</button>"; }).join("") + "</div>";
    if (view.err) out += '<p class="err" role="alert">' + esc(view.err) + "</p>";
    out += view.tt === "sets" ? (view.editing ? editorHTML() : setsTab()) : view.tt === "students" ? studentsTab() : view.tt === "subs" ? subsTab() : settingsTab();
    return out + "</main>";
  }
  function setsTab() {
    var list = T.sets.filter(function (s) { return !view.lvF || s.lv === view.lvF; });
    var h = '<div class="bar"><h2>Bài tập đã giao</h2><div class="row"><select id="t-lv" aria-label="Lọc theo trình độ"><option value="">Mọi trình độ</option>' + lvOptions(view.lvF) + '</select><button class="btn" type="button" data-act="s-new">+ Tạo bài tập</button></div></div>';
    if (view.msg) h += '<p class="okmsg" role="status">' + esc(view.msg) + "</p>";
    if (!list.length) return h + '<div class="card"><div class="empty"><h3>Chưa có bài tập nào</h3><p>Bấm Tạo bài tập, hoặc thêm 12 bài mẫu (mỗi trình độ đủ 4 kỹ năng) để xem thử.</p></div><div class="row" style="justify-content:center"><button class="btn alt" type="button" data-act="s-sample"' + (view.busy ? " disabled" : "") + ">Thêm bài mẫu</button></div></div>";
    list.forEach(function (s) {
      var n = T.subs.filter(function (x) { return x.e === s.id; }).length;
      h += '<div class="card set"><div class="meta"><b>' + esc(s.title) + '</b><div class="chips">' + pills(s, s.qs.length) + '<span class="pill">' + n + ' bài nộp</span>' + (s.due ? '<span class="dim">Hạn ' + fmtDue(s.due) + "</span>" : "") + '</div></div><div class="row">' +
        '<button class="txtbtn" type="button" data-act="s-edit" data-id="' + s.id + '">Sửa</button><button class="txtbtn" type="button" data-act="s-dup" data-id="' + s.id + '">Nhân bản</button>' + confirmBtn("s-del", s.id, "Xóa") + "</div></div>";
    });
    return h;
  }
  function blankQ() { return { audio: "", passage: "", q: "", o: ["", "", "", ""], a: -1, answersText: "", why: "" }; }
  function toDraft(s) {
    return { id: s.id, title: s.title, lv: s.lv, skill: s.skill, due: s.due || "", qs: s.qs.map(function (q) {
      return { audio: q.audio || "", passage: q.passage || "", q: q.q, o: (q.o || []).concat(["", "", "", ""]).slice(0, 4), a: isText(q) ? -1 : q.a, answersText: isText(q) ? q.answers.join("\n") : "", why: q.why || "" };
    }) };
  }
  function editorHTML() {
    var d = view.draft;
    var h = '<section class="card"><h2>' + (view.editing === "new" ? "Tạo bài tập" : "Sửa bài tập") + "</h2>" +
      '<div class="two"><div class="field"><label for="d-title">Tên bài</label><input id="d-title" type="text" data-f="title" placeholder="Unit 1" value="' + esc(d.title) + '"></div>' +
      '<div class="field"><label for="d-due">Hạn nộp</label><input id="d-due" type="date" data-f="due" value="' + esc(d.due) + '"></div>' +
      '<div class="field"><label for="d-lv">Trình độ</label><select id="d-lv" data-f="lv">' + lvOptions(d.lv) + "</select></div>" +
      '<div class="field"><label for="d-skill">Kỹ năng</label><select id="d-skill" data-f="skill">' + SKO.map(function (k) { return '<option value="' + k + '"' + (d.skill === k ? " selected" : "") + ">" + SK[k] + "</option>"; }).join("") + "</select></div></div></section>";
    d.qs.forEach(function (q, i) {
      h += '<section class="card"><div class="qhead"><h3>Câu ' + (i + 1) + "</h3>" + (d.qs.length > 1 ? '<button class="txtbtn red" type="button" data-act="q-del" data-q="' + i + '">Xóa câu</button>' : "") + "</div>";
      if (d.skill === "listen") h += '<div class="field"><label for="q' + i + '-audio">Nội dung đọc to bằng tiếng Anh (học sinh chỉ nghe, không thấy chữ)</label><textarea id="q' + i + '-audio" data-f="audio" data-q="' + i + '">' + esc(q.audio) + '</textarea><div><button class="btn alt" type="button" data-act="q-test" data-q="' + i + '">Nghe thử</button></div></div>';
      if (d.skill === "read") h += '<div class="field"><label for="q' + i + '-passage">Đoạn văn</label><textarea id="q' + i + '-passage" data-f="passage" data-q="' + i + '">' + esc(q.passage) + "</textarea></div>";
      h += '<div class="field"><label for="q' + i + '-q">Câu hỏi</label><textarea id="q' + i + '-q" data-f="q" data-q="' + i + '">' + esc(q.q) + "</textarea></div>";
      if (d.skill === "write") h += '<div class="field"><label for="q' + i + '-ans">Đáp án chấp nhận (mỗi dòng một đáp án, không phân biệt hoa thường)</label><textarea id="q' + i + '-ans" data-f="answersText" data-q="' + i + '">' + esc(q.answersText) + "</textarea></div>";
      else {
        h += '<div class="field"><span class="lab">Đáp án (nhập ít nhất A và B, chọn ô đúng)</span>';
        for (var k = 0; k < 4; k++) h += '<div class="optrow"><input type="text" data-f="o" data-q="' + i + '" data-o="' + k + '" aria-label="Đáp án ' + LET[k] + '" placeholder="Đáp án ' + LET[k] + '" value="' + esc(q.o[k]) + '"><label class="pick"><input type="radio" name="ans-' + i + '" data-f="a" data-q="' + i + '" value="' + k + '"' + (q.a === k ? " checked" : "") + "> Đúng</label></div>";
        h += "</div>";
      }
      h += '<div class="field"><label for="q' + i + '-why">Giải thích (không bắt buộc)</label><input id="q' + i + '-why" type="text" data-f="why" data-q="' + i + '" value="' + esc(q.why) + '"></div></section>';
    });
    if (view.err2) h += '<p class="err" role="alert">' + esc(view.err2) + "</p>";
    h += '<div class="row"><button class="btn alt" type="button" data-act="q-add">+ Thêm câu hỏi</button><button class="btn" type="button" data-act="s-save"' + (view.busy ? " disabled" : "") + ">" + (view.busy ? "Đang lưu..." : "Lưu bài tập") + '</button><button class="txtbtn" type="button" data-act="s-cancel">Huỷ</button></div>';
    return h;
  }
  function draftToBody(d) {
    var skill = d.skill;
    return { id: d.id, title: d.title, lv: d.lv, skill: skill, due: d.due, qs: d.qs.map(function (q) {
      var o = { q: q.q, why: q.why };
      if (skill === "listen") o.audio = q.audio;
      if (skill === "read") o.passage = q.passage;
      if (skill === "write") o.answers = q.answersText.split("\n").map(function (x) { return x.trim(); }).filter(Boolean);
      else {
        var map = {}, arr = [];
        q.o.forEach(function (t, k) { if (t.trim()) { map[k] = arr.length; arr.push(t.trim()); } });
        o.o = arr; o.a = map[q.a] === undefined ? -1 : map[q.a];
      }
      return o;
    }) };
  }
  async function saveDraft() {
    view.err2 = "";
    view.busy = true; render();
    try {
      var body = draftToBody(view.draft);
      if (view.editing === "new") delete body.id;
      await api("POST", "t/sets", body);
      view.editing = null; view.draft = null; view.msg = "Đã lưu bài tập.";
      await loadT();
    } catch (e) { if (e.handled) return; view.err2 = e.message; }
    view.busy = false; render();
  }
  function studentsTab() {
    var h = "";
    if (view.fresh.length) {
      var txt = view.fresh.map(function (f) { return f.name + " | tên đăng nhập: " + f.user + " | mật khẩu: " + f.pass; }).join("\n");
      h += '<section class="card"><h3>Thông tin đăng nhập vừa tạo</h3><p class="hint">Mật khẩu chỉ hiện ở đây một lần. Ghi lại hoặc gửi cho học sinh.</p><pre class="creds" id="creds">' + esc(txt) + '</pre><div class="row"><button class="btn" type="button" data-act="fresh-copy">Sao chép</button><button class="btn alt" type="button" data-act="fresh-hide">Đã ghi lại, ẩn đi</button></div></section>';
    }
    h += '<form class="card" data-form="bulk"><h3>Tạo tài khoản nhanh cho cả lớp</h3><p class="hint">Chỉ cần gõ họ tên, mỗi dòng một bạn. Hệ thống tự đặt tên đăng nhập và mật khẩu.</p>' +
      '<textarea id="bulk" aria-label="Danh sách học sinh" placeholder="Nguyễn Minh Khang&#10;Trần Bảo Ngọc"></textarea>' +
      '<div class="row"><select id="b-lv" aria-label="Trình độ">' + lvOptions(view.bulkLv || "g12") + '</select><button class="btn" type="submit"' + (view.busy ? " disabled" : "") + ">Tạo tài khoản</button></div>" +
      '<details><summary>Tự đặt tên đăng nhập và mật khẩu</summary><div class="two" style="margin-top:8px"><div class="field"><label for="m-name">Họ tên</label><input id="m-name" type="text"></div><div class="field"><label for="m-user">Tên đăng nhập</label><input id="m-user" type="text" autocapitalize="none"></div><div class="field"><label for="m-pin">Mật khẩu</label><input id="m-pin" type="text"></div></div><div class="row" style="margin-top:10px"><button class="btn alt" type="button" data-act="stu-manual">Thêm học sinh này</button></div></details></form>';
    if (!T.students.length) return h + '<div class="card"><div class="empty"><h3>Chưa có học sinh nào</h3><p>Tạo tài khoản ở trên để học sinh đăng nhập.</p></div></div>';
    T.students.forEach(function (s) {
      var mine = T.subs.filter(function (x) { return x.sid === s.id; });
      var sticks = mine.reduce(function (a, x) { return a + x.c; }, 0);
      if (view.editStu === s.id) {
        h += '<form class="card" data-form="stu-edit" data-id="' + s.id + '"><h3>Sửa học sinh</h3><div class="two"><div class="field"><label for="e-name">Họ tên</label><input id="e-name" type="text" value="' + esc(s.name) + '"></div><div class="field"><label for="e-lv">Trình độ</label><select id="e-lv">' + lvOptions(s.lv) + '</select></div></div><p class="hint">Tên đăng nhập: ' + esc(s.user) + '</p><div class="row"><button class="btn" type="submit">Lưu</button><button class="btn alt" type="button" data-act="stu-pin" data-id="' + s.id + '">Đặt lại mật khẩu</button><button class="txtbtn" type="button" data-act="stu-cancel">Huỷ</button></div></form>';
        return;
      }
      h += '<div class="card"><div class="stu"><div class="avatar">' + STUAV + '</div><div class="meta"><b>' + esc(s.name) + '</b><span class="dim">Tên đăng nhập: <b>' + esc(s.user) + "</b>, " + (mine.length ? "đã nộp " + mine.length + " bài" : "chưa nộp bài nào") + '</span><div class="chips"><span class="pill solid">' + LV[s.lv] + '</span><span class="pill gold">' + ICON.stick + (sticks ? "+" + sticks + " nhang từ các bài đã nộp" : "Chưa có nhang") + '</span></div></div><div class="row"><button class="txtbtn" type="button" data-act="stu-edit" data-id="' + s.id + '">Sửa</button>' + confirmBtn("stu-del", s.id, "Xóa") + "</div></div></div>";
    });
    return h;
  }
  function subsTab() {
    var h = '<div class="bar"><h2>Bài đã nộp</h2><div class="row"><button class="btn alt" type="button" data-act="refresh">Làm mới</button><button class="btn alt" type="button" data-act="export">Tải bảng điểm (CSV)</button></div></div>';
    var subs = T.subs.slice().sort(function (a, b) { return b.at - a.at; });
    if (!subs.length) return h + '<div class="card"><div class="empty"><h3>Chưa có bài nộp</h3><p>Khi học sinh làm xong một bài, bài nộp sẽ hiện ở đây. Trang tự cập nhật mỗi 15 giây.</p></div></div>';
    subs.forEach(function (x) {
      var st = byId(T.students, x.sid), s = byId(T.sets, x.e); if (!st || !s) return;
      h += '<div class="card set" style="border-left-width:2px"><div class="meta"><b>' + esc(st.name) + ": " + esc(s.title) + '</b><div class="chips"><span class="pill solid">' + LV[s.lv] + '</span><span class="pill solid">' + ICON[s.skill] + SK[s.skill] + '</span><span class="pill">' + x.c + "/" + x.t + '</span><span class="pill gold">+' + x.c + " " + ICON.stick + '</span><span class="dim">' + fmtAt(x.at) + '</span></div></div><div class="row"><button class="btn" type="button" data-act="sub-open" data-id="' + x.sid + "~" + x.e + '">' + (view.openSub === x.sid + "~" + x.e ? "Ẩn bài" : "Xem bài") + "</button>" + confirmBtn("sub-del", x.sid, "Xóa", x.e) + "</div>";
      if (view.openSub === x.sid + "~" + x.e) {
        h += '<div class="review">' + s.qs.map(function (q, i) {
          var a = x.a[i], good = isText(q) ? q.answers.map(norm).indexOf(norm(a)) > -1 : a === q.a;
          var shown = isText(q) ? String(a) : (q.o[a] != null ? LET[a] + ". " + q.o[a] : "(chưa trả lời)");
          return '<div class="rq"><b>Câu ' + (i + 1) + ": " + esc(q.q) + '</b><span>Học sinh chọn: ' + esc(shown) + ' <span class="pill ' + (good ? "good" : "bad") + '">' + (good ? "Đúng" : "Sai") + "</span></span>" + (good ? "" : '<span class="dim">Đáp án: ' + esc(isText(q) ? q.answers[0] : LET[q.a] + ". " + q.o[q.a]) + "</span>") + "</div>";
        }).join("") + "</div>";
      }
      h += "</div>";
    });
    return h;
  }
  function settingsTab() {
    return '<h2>Cài đặt</h2><section class="card"><h3>Mật khẩu và tên hiển thị</h3><p class="hint">Mật khẩu giáo viên và tên hiển thị được đặt trong Netlify: Site configuration, Environment variables, biến TEACHER_PASSWORD và TEACHER_NAME. Sau khi đổi, bấm Deploys, Trigger deploy để áp dụng.</p></section>' +
      '<section class="card"><h3>Dữ liệu</h3><p class="hint">Tài khoản, bài tập và bài nộp được lưu trên Netlify Blobs của trang này. Nhang của học sinh được tính từ số câu đúng trong các bài đã làm, và mỗi lần thắp nhang trừ 3 cây.</p></section>';
  }
  function exportCSV() {
    var rows = [["Học sinh", "Tên đăng nhập", "Trình độ", "Bài tập", "Kỹ năng", "Điểm", "Tổng câu", "Nhang", "Nộp lúc"]];
    T.subs.slice().sort(function (a, b) { return a.at - b.at; }).forEach(function (x) {
      var st = byId(T.students, x.sid), s = byId(T.sets, x.e); if (!st || !s) return;
      var d = new Date(x.at);
      rows.push([st.name, st.user, LV[s.lv], s.title, SK[s.skill], x.c, x.t, x.c, d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()) + " " + pad(d.getHours()) + ":" + pad(d.getMinutes())]);
    });
    var csv = "﻿" + rows.map(function (r) { return r.map(function (c) { return '"' + String(c).replace(/"/g, '""') + '"'; }).join(","); }).join("\r\n");
    var url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    var a = document.createElement("a"); a.href = url; a.download = "bang-diem-merit-hall.csv"; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  /* ---------- Bài mẫu ---------- */
  function mc(q, o, a, why, ex) { return Object.assign({ q: q, o: o, a: a, why: why }, ex || {}); }
  function tx(q, answers, why) { return { q: q, answers: answers, why: why }; }
  var MUSEUM = "The museum opens at 9 a.m. on weekdays and 10 a.m. at weekends. Entry is free for children under 12.";
  function sampleSets() {
    var due = todayStr(7);
    var L = function (lv, skill, title, qs) { return { title: title, lv: lv, skill: skill, due: due, qs: qs }; };
    return [
      L("g12", "listen", "Mẫu Lớp 12 · Nghe", [
        mc("What time does the train leave?", ["6:30", "7:30", "8:30"], 1, "Người nói nói tàu rời ga lúc bảy giờ rưỡi.", { audio: "The train to Da Nang leaves at half past seven, so please be at the station by seven." }),
        mc("Why does the speaker stay at home?", ["She is ill.", "She has an exam tomorrow.", "She has no money."], 1, "Cô ấy nói mình ở nhà vì ngày mai có bài kiểm tra.", { audio: "I'd rather stay home tonight because I have an exam tomorrow." })
      ]),
      L("g12", "speak", "Mẫu Lớp 12 · Nói", [
        mc("A: \"Would you mind opening the window?\"  B: ___", ["Not at all.", "Yes, I would.", "No, I mind."], 0, "Would you mind...? Trả lời Not at all nghĩa là không phiền, sẵn sàng giúp."),
        mc("A: \"I passed my driving test!\"  B: ___", ["That's too bad.", "Congratulations! Well done.", "I don't care."], 1, "Đáp lại tin vui bằng lời chúc mừng.")
      ]),
      L("g12", "read", "Mẫu Lớp 12 · Đọc", [
        mc("What did many students enjoy about remote learning?", ["The flexibility", "The long lessons", "The exams"], 0, "Bài đọc nói nhiều học sinh thích sự linh hoạt.", { passage: "Remote learning became common during the pandemic. Many students enjoyed the flexibility, but some felt isolated because they rarely met their classmates." }),
        mc("Why did some students feel isolated?", ["They disliked the teachers.", "They rarely met their classmates.", "They had too much homework."], 1, "Bài đọc nói họ hiếm khi gặp bạn học.", { passage: "Remote learning became common during the pandemic. Many students enjoyed the flexibility, but some felt isolated because they rarely met their classmates." })
      ]),
      L("g12", "write", "Mẫu Lớp 12 · Viết", [
        tx("Complete the sentence: She has lived here ___ 2015.", ["since"], "since + mốc thời gian (2015)."),
        tx("Complete the sentence: If I ___ (be) you, I would study harder.", ["were", "was"], "Điều kiện loại 2 dùng were (hoặc was) cho mọi chủ ngữ.")
      ]),
      L("pet", "listen", "Mẫu PET · Nghe", [
        mc("When is the football match now?", ["At two o'clock", "At four o'clock", "On Sunday morning"], 1, "Trận đấu được dời từ hai giờ sang bốn giờ.", { audio: "Hello, this is Tom. The football match on Saturday has been moved from two o'clock to four o'clock because of the weather." }),
        mc("Why was the match moved?", ["The weather was bad.", "The teacher was ill.", "The pitch was closed."], 0, "Người nói nêu lý do là thời tiết.", { audio: "Hello, this is Tom. The football match on Saturday has been moved from two o'clock to four o'clock because of the weather." })
      ]),
      L("pet", "speak", "Mẫu PET · Nói", [
        mc("\"Would you like to come to the cinema with me?\"  \"___\"", ["I'd love to, thanks.", "Yes, I'm going.", "It's a good film."], 0, "Nhận lời mời lịch sự: I'd love to, thanks."),
        mc("\"Excuse me, how do I get to the station?\"  \"___\"", ["It's very nice.", "At six o'clock.", "Go straight on and turn left."], 2, "Câu hỏi đường thì chỉ đường.")
      ]),
      L("pet", "read", "Mẫu PET · Đọc", [
        mc("Why is Beth writing?", ["To say she can't come", "To accept an invitation and ask about the time", "To ask Anna to play football"], 1, "Beth nhận lời đến dự tiệc nhưng hỏi có thể đến muộn không.", { passage: "Dear Anna, thanks for your invitation. I'd love to come to your party on Friday, but I have football practice until seven. Can I arrive at half past seven? Love, Beth" }),
        mc("What time can Beth arrive?", ["7:00", "7:30", "8:00"], 1, "Beth hỏi có thể đến lúc bảy giờ rưỡi.", { passage: "Dear Anna, thanks for your invitation. I'd love to come to your party on Friday, but I have football practice until seven. Can I arrive at half past seven? Love, Beth" })
      ]),
      L("pet", "write", "Mẫu PET · Viết", [
        tx("Complete the sentence: I ___ seen him since last week. (not)", ["haven't", "have not"], "Hiện tại hoàn thành phủ định: haven't + V3."),
        tx("Complete the sentence: She is ___ than her sister. (tall)", ["taller"], "So sánh hơn của tính từ ngắn: tall - taller.")
      ]),
      L("ielts", "listen", "Mẫu IELTS · Nghe", [
        mc("What time does the library close on Sundays?", ["5 p.m.", "8:30 p.m.", "9 p.m."], 0, "Chủ nhật thư viện đóng cửa lúc năm giờ chiều.", { audio: "The library opens at eight thirty in the morning and closes at nine in the evening, except on Sundays, when it closes at five." }),
        mc("When does the library open?", ["8:30 a.m.", "9:00 a.m.", "5:00 a.m."], 0, "Thư viện mở cửa lúc tám giờ rưỡi sáng.", { audio: "The library opens at eight thirty in the morning and closes at nine in the evening, except on Sundays, when it closes at five." })
      ]),
      L("ielts", "speak", "Mẫu IELTS · Nói", [
        mc("Examiner: \"Do you enjoy cooking?\" Which answer extends best?", ["Yes.", "Yes, because it helps me relax. For example, I often cook with my family at weekends.", "No idea."], 1, "Nêu lý do kèm ví dụ giúp câu trả lời đủ dài và tự nhiên."),
        mc("Which phrase is best for buying thinking time?", ["I don't know.", "That's an interesting question. Let me think.", "Next question, please."], 1, "Cụm này lịch sự và cho bạn vài giây suy nghĩ.")
      ]),
      L("ielts", "read", "Mẫu IELTS · Đọc (True / False / Not Given)", [
        mc("Statement: Children under 12 pay a reduced fee.", ["True", "False", "Not Given"], 1, "Văn bản nói trẻ dưới 12 tuổi được vào miễn phí, mâu thuẫn với giảm giá: False.", { passage: MUSEUM }),
        mc("Statement: The museum has a café.", ["True", "False", "Not Given"], 2, "Đoạn văn không nhắc đến quán cà phê: Not Given.", { passage: MUSEUM })
      ]),
      L("ielts", "write", "Mẫu IELTS · Viết", [
        tx("Complete: The graph shows a sharp ___ in sales. (rise / increase)", ["rise", "increase"], "Dùng danh từ chỉ xu hướng tăng."),
        tx("Complete with a linking word of contrast: Prices went up; ___, demand stayed high.", ["however"], "Hai vế đối lập nên dùng however.")
      ])
    ];
  }

  /* ---------- Vẽ ---------- */
  function render() {
    var app = $("app");
    if (!token) { app.innerHTML = loginHTML(); return; }
    if (role === "teacher") { app.innerHTML = T ? teacherHTML() : header(esc(who) + '<button class="txtbtn" type="button" data-act="logout">Đăng xuất</button>') + '<main class="page"><p class="loading">' + (view.err ? esc(view.err) : "Đang tải...") + "</p></main>"; return; }
    var head = header(esc(who) + '<button class="txtbtn" type="button" data-act="logout">Đăng xuất</button>');
    if (!H) { app.innerHTML = head + '<main class="page"><p class="loading">' + (view.err ? esc(view.err) : "Đang tải...") + "</p></main>"; return; }
    app.innerHTML = head + '<main class="page">' + (Q ? quizView() : studentHome()) + "</main>";
  }

  /* ---------- Sự kiện ---------- */
  function onField(t) {
    var d = view.draft; if (!d || t.dataset.f === undefined) return;
    var f = t.dataset.f;
    if (t.dataset.q === undefined) { d[f] = t.value; if (f === "skill") render(); return; }
    var q = d.qs[+t.dataset.q]; if (!q) return;
    if (f === "o") q.o[+t.dataset.o] = t.value;
    else if (f === "a") q.a = +t.value;
    else q[f] = t.value;
  }
  document.addEventListener("input", function (e) { var t = e.target; if (t.dataset && t.dataset.f !== undefined && t.dataset.f !== "skill" && t.type !== "radio") onField(t); });
  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.dataset && t.dataset.f !== undefined) onField(t);
    else if (t.id === "t-lv") { view.lvF = t.value; render(); }
    else if (t.id === "sk-f") { view.skF = t.value; render(); }
  });
  function addFresh(list) { view.fresh = view.fresh.concat(list); ssSet("mh-fresh", JSON.stringify(view.fresh)); }
  document.addEventListener("submit", function (e) {
    var f = e.target.closest("form"); if (!f) return;
    e.preventDefault();
    var k = f.dataset.form;
    if (k === "login") doLogin();
    else if (k === "type") { var v = $("typed").value.trim(); if (v) answerQ(v); }
    else if (k === "bulk") {
      var names = $("bulk").value.split("\n").map(function (s) { return s.trim(); }).filter(Boolean);
      if (!names.length) return;
      view.bulkLv = $("b-lv").value;
      tact(async function () { var d = await api("POST", "t/students/bulk", { names: names, lv: view.bulkLv }); addFresh(d.created); });
    }
    else if (k === "stu-edit") {
      var id = f.dataset.id, nm = $("e-name").value.trim(), lv = $("e-lv").value;
      if (nm) tact(async function () { await api("PUT", "t/students/" + id, { name: nm, lv: lv }); view.editStu = null; });
    }
  });
  function copyEl(id, btn) {
    var el = $(id), txt = el.textContent;
    var sel = function () { var r = document.createRange(); r.selectNodeContents(el); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); };
    try { navigator.clipboard.writeText(txt).then(function () { btn.textContent = "Đã sao chép"; }, sel); } catch (x) { sel(); }
  }
  document.addEventListener("click", function (e) {
    var t = e.target.closest("button"); if (!t) return;
    if (t.dataset.opt !== undefined) { answerQ(+t.dataset.opt); return; }
    var act = t.dataset.act; if (!act) return;
    var id = t.dataset.id, yes = t.dataset.yes;
    switch (act) {
      case "login-as": view.loginAs = t.dataset.as; view.err = ""; render(); break;
      case "logout": logout(); view.err = ""; render(); break;
      case "light": lightIncense(); break;
      case "open": openSet(id); break;
      case "back": Q = null; view.err = ""; loadH().then(render).catch(function () {}); render(); break;
      case "next": Q.qi += 1; Q.fb = null; render(); break;
      case "play": speak(Q.qs[Q.qi].audio); break;
      case "c-no": view.confirm = ""; render(); break;
      case "t-tab": view.tt = t.dataset.tt; view.err = ""; view.msg = ""; view.editing = null; view.draft = null; render(); if (view.tt === "subs") tact(function () { return Promise.resolve(); }); break;
      case "refresh": tact(function () { return Promise.resolve(); }); break;
      case "export": exportCSV(); break;
      case "s-new": view.editing = "new"; view.err2 = ""; view.msg = ""; view.draft = { id: "", title: "", lv: view.lvF || "g12", skill: "listen", due: todayStr(7), qs: [blankQ()] }; render(); break;
      case "s-edit": var s1 = byId(T.sets, id); if (s1) { view.editing = id; view.err2 = ""; view.msg = ""; view.draft = toDraft(s1); render(); } break;
      case "s-dup":
        var s2 = byId(T.sets, id);
        if (s2) tact(async function () { var c = clone(s2); delete c.id; c.title += " (bản sao)"; await api("POST", "t/sets", c); view.msg = "Đã nhân bản bài tập."; });
        break;
      case "s-del":
        if (!yes) { view.confirm = act + ":" + id; render(); return; }
        view.confirm = ""; tact(function () { return api("DELETE", "t/sets/" + id); }); break;
      case "s-sample":
        tact(async function () { var all = sampleSets(); for (var i = 0; i < all.length; i++) await api("POST", "t/sets", all[i]); view.msg = "Đã thêm 12 bài mẫu."; });
        break;
      case "s-save": saveDraft(); break;
      case "s-cancel": view.editing = null; view.draft = null; view.err2 = ""; render(); break;
      case "q-add": view.draft.qs.push(blankQ()); render(); break;
      case "q-del": view.draft.qs.splice(+t.dataset.q, 1); render(); break;
      case "q-test": speak(view.draft.qs[+t.dataset.q].audio); break;
      case "stu-edit": view.editStu = id; render(); break;
      case "stu-cancel": view.editStu = null; render(); break;
      case "stu-del":
        if (!yes) { view.confirm = act + ":" + id; render(); return; }
        view.confirm = ""; tact(function () { return api("DELETE", "t/students/" + id); }); break;
      case "stu-pin":
        tact(async function () { var d = await api("PUT", "t/students/" + id, { reset: true }); addFresh([{ name: d.name, user: d.user, pass: d.pass }]); view.editStu = null; });
        break;
      case "stu-manual":
        var nm = $("m-name").value.trim(), us = $("m-user").value.trim(), pw = $("m-pin").value.trim(), lv = $("b-lv").value;
        tact(async function () { var d = await api("POST", "t/students", { name: nm, user: us, pass: pw, lv: lv }); addFresh(d.created); });
        break;
      case "fresh-hide": view.fresh = []; ssDel("mh-fresh"); render(); break;
      case "fresh-copy": copyEl("creds", t); break;
      case "sub-open": view.openSub = view.openSub === id ? null : id; render(); break;
      case "sub-del":
        if (!yes) { view.confirm = act + ":" + id + t.dataset.x; render(); return; }
        view.confirm = ""; tact(function () { return api("DELETE", "t/subs/" + id + "/" + t.dataset.x); }); break;
    }
  });

  render();
  if (token) boot();
})();
