# Merit Hall

Trang giao bài tập Lớp 12, PET, IELTS đủ 4 kỹ năng (Nghe, Nói, Đọc, Viết). Học sinh làm đúng thì tích nhang, đủ 3 cây thì thắp nhang để thầy ban 3 phước. Học sinh nộp bài là giáo viên thấy ngay ở tab Bài đã nộp, không cần mã.

## Có gì trong thư mục này

- `public/` giao diện (index.html, style.css, app.js)
- `netlify/functions/api.mjs` máy chủ nhỏ: đăng nhập, tài khoản, bài tập, chấm bài, bài nộp. Dữ liệu lưu bằng Netlify Blobs (có sẵn trên Netlify, không cần cài thêm gì).
- `netlify.toml`, `package.json` cấu hình cho Netlify

## Đưa lên Netlify (cách dễ nhất, qua GitHub)

Nên tạo một site mới để không ghi đè trang Mèo Học Tiếng Anh đang chạy.

1. Vào github.com, tạo một repository mới (đặt tên tùy ý, ví dụ `merit-hall`).
2. Bấm Add file, Upload files, kéo toàn bộ nội dung thư mục này vào (giữ nguyên thư mục `public` và `netlify`), rồi bấm Commit changes.
3. Vào app.netlify.com, bấm Add new site, Import an existing project, chọn GitHub và repository vừa tạo. Giữ nguyên các ô cấu hình, bấm Deploy.
4. Trước khi dùng, vào Site configuration, Environment variables, thêm:
   - `TEACHER_PASSWORD`: mật khẩu giáo viên của bạn (bắt buộc)
   - `TEACHER_NAME`: tên hiện ở góc phải, ví dụ `Ms Hân` (không bắt buộc)
5. Vào Deploys, bấm Trigger deploy, Deploy site để biến môi trường có hiệu lực.

Xong. Mở trang, bấm "Dành cho giáo viên", đăng nhập bằng `TEACHER_PASSWORD`.

## Đưa lên bằng dòng lệnh (nếu bạn quen)

```
npm install
npx netlify-cli login
npx netlify-cli deploy --prod
```

Rồi đặt `TEACHER_PASSWORD` như bước 4 ở trên và deploy lại.

## Cách dùng

1. Giáo viên đăng nhập, vào tab Học sinh, gõ họ tên cả lớp (mỗi dòng một bạn), chọn trình độ rồi bấm Tạo tài khoản. Mật khẩu chỉ hiện một lần, hãy ghi lại hoặc gửi cho học sinh.
2. Vào tab Bài tập, bấm Tạo bài tập, chọn trình độ và kỹ năng. Học sinh chỉ thấy bài của đúng trình độ mình.
3. Học sinh đăng nhập, làm bài, mỗi câu đúng được 1 cây nhang. Câu trả lời được chấm trên máy chủ nên học sinh không xem được đáp án trước khi làm.
4. Tab Bài đã nộp tự cập nhật, bấm Xem bài để xem từng câu, hoặc Tải bảng điểm (CSV) để mở bằng Excel.

## Lưu ý

- Mỗi câu chỉ được trả lời một lần. Nếu sửa nội dung một bài đã có người làm, kết quả cũ vẫn giữ nguyên nhưng có thể không khớp câu hỏi mới. Muốn cho làm lại, hãy xóa bài rồi tạo lại.
- Mật khẩu học sinh được băm trên máy chủ. Phiên đăng nhập học sinh 30 ngày, giáo viên 14 ngày.
- Phần Nghe dùng giọng đọc có sẵn của trình duyệt (nên dùng Chrome hoặc Edge). Phần Nói chọn câu đáp lại, trang không chấm phát âm.
